# Màn hình ngủ lấy số liệu từ script như thế nào?

App không tự tính gì, chỉ ĐỌC rồi HIỂN THỊ. Có 3 nguồn (ưu tiên từ trên xuống):

1. Script gọi (thêm vào script của bạn, khi có số liệu mới):

   TTV_REPORT({
     pokemon: 'Pikachu',
     level: 25,
     gold: 123456,                       // số hoặc chuỗi "1.2K", "12,345"
     farmed: 'Rare Candy x2, Kill 523'   // chuỗi, mảng, hoặc object {Kill:523}
   });

2. Script gán sẵn object (app tự đọc mỗi 5-8 giây):

   window.TTV_STATE = { pokemon, level, gold, farmed };

3. Tự quét chữ trên trang (dự phòng): nhận dạng "Lv/Level/Cấp 25", "Gold/Vàng/Coins 1,234",
   "Pokémon: Tên". Chỉ chạy được nếu HUD của game là chữ HTML, không phải canvas.

Vàng đã kiếm = tổng phần vàng TĂNG THÊM từ lúc bắt đầu phiên (tiêu vàng không bị trừ).
Thời gian treo tính từ lúc mở app; menu có nút "Đặt lại phiên".
