package com.example.scriptweb

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.RippleDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.ScriptHandler
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import kotlin.math.abs

/** ScrollView có chiều cao tối đa, để bảng menu không bao giờ tràn màn hình. */
private class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) =
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
}

class MainActivity : AppCompatActivity() {
    private val START_URL = "https://pokesurvivor.com/"
    // Chặn đoạn kiểm tra cập nhật dành cho bản Chrome extension (script tự bỏ qua nếu có GM_info)
    private val PRELUDE = "window.GM_info = window.GM_info || {};\n"
    private val ecoNames = arrayOf("Tắt", "Cân bằng", "Tối đa")

    private lateinit var web: WebView
    private lateinit var store: ScriptStore
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var fab: ImageView
    private lateinit var sleepView: SleepView
    private val ui = Handler(Looper.getMainLooper())
    private val handlers = mutableListOf<ScriptHandler>()
    private val proxies = ArrayDeque<JavaScriptReplyProxy>()
    private val engine by lazy { assets.open("ttv_engine.js").bufferedReader().use { it.readText() } }

    // ---- Trạng thái ----
    private var eco = 1                 // 0 = Tắt, 1 = Cân bằng, 2 = Tối đa
    private var sleeping = false
    private var tempC = 0f
    private var battPct = -1
    private var lastPushed = ""
    private var ticks = 0
    private var fabFx = 1f
    private var fabFy = 0.75f

    // ---- Bảng màu (tự đổi theo chế độ sáng/tối) ----
    private val night get() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private val accent = 0xFF00B041.toInt()
    private val danger = 0xFFE53935.toInt()
    private val cSurface get() = if (night) 0xFF1F2421.toInt() else 0xFFFFFFFF.toInt()
    private val cCard get() = if (night) 0xFF2B312D.toInt() else 0xFFF1F5F2.toInt()
    private val cText get() = if (night) 0xFFF2F5F3.toInt() else 0xFF18201B.toInt()
    private val cMuted get() = if (night) 0xFF9AA59E.toInt() else 0xFF66726B.toInt()
    private val cDangerBg get() = if (night) 0xFF3D2625.toInt() else 0xFFFDECEA.toInt()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@registerForActivityResult
        val code = contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
        if (code.isBlank()) { toast("File rỗng"); return@registerForActivityResult }
        store.add(code); applyScripts(); web.reload(); toast("Đã thêm tiện ích")
    }

    private val battery = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            battPct = if (lvl >= 0) lvl * 100 / scale else -1
            pushConfig()
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!sleeping) return
            sleepView.refresh(statusLine())
            if (++ticks % 60 == 0) sleepView.drift()
            ui.postDelayed(this, 1000)
        }
    }
    private val fadeFab = Runnable { if (!sleeping) fab.animate().alpha(0.45f).setDuration(300).start() }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // không tắt màn hình khi dùng app
        prefs = getSharedPreferences("ttv_settings", MODE_PRIVATE)
        eco = prefs.getInt("eco", 1).coerceIn(0, 2)
        fabFx = prefs.getFloat("fab_fx", 1f)
        fabFy = prefs.getFloat("fab_fy", 0.75f)
        store = ScriptStore(this).also { it.removeLegacyDefault() }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(false)
            overScrollMode = View.OVER_SCROLL_NEVER
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    proxies.clear()   // frame cũ đã hết hiệu lực, frame mới sẽ tự đăng ký lại
                    super.onPageStarted(view, url, favicon)
                }
            }
            webChromeClient = WebChromeClient()
        }

        // Cầu nối: script gọi TTV_REPORT(...) -> app nhận số liệu để hiện lên màn hình ngủ
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web, "TTV", setOf("*"),
                WebViewCompat.WebMessageListener { _, message, _, _, reply -> onBridge(message, reply) })
        }

        root = FrameLayout(this)
        root.addView(web, ViewGroup.LayoutParams(-1, -1))

        // Nút logo: kéo thả, tự hít vào mép, mờ khi không dùng. Bấm = mở menu, giữ lâu = ngủ ngay.
        val size = dp(52)
        fab = roundedImage(R.drawable.logo, size / 2).apply {
            elevation = dp(6).toFloat(); alpha = 0.95f
            contentDescription = "Tiện ích"
        }
        root.addView(fab, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START))
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!fabDragging) placeFab(false) }
        setupFabTouch()

        sleepView = SleepView(this) { exitSleep() }.apply { visibility = View.GONE }
        root.addView(sleepView, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)

        ContextCompat.registerReceiver(this, battery, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    sleeping -> exitSleep()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        applyScripts()
        scheduleFade()
        web.loadUrl(START_URL)
    }

    override fun onStart() { super.onStart(); if (sleeping) { ui.removeCallbacks(tick); ui.post(tick) } }
    override fun onStop() { ui.removeCallbacks(tick); super.onStop() }
    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { unregisterReceiver(battery) } catch (_: Exception) {}
        super.onDestroy()
    }

    // ================= Tối ưu chống nóng máy =================

    /** Giới hạn FPS theo chế độ tiết kiệm, đang ngủ hay không, và nhiệt độ pin. 0 = không giới hạn. */
    private fun effectiveFps(): Int {
        if (eco == 0) return 0
        var f = when {
            eco == 1 && sleeping -> 20
            eco == 1 -> 30
            sleeping -> 10
            else -> 20
        }
        f = when {
            tempC >= 45f -> minOf(f, 8)
            tempC >= 42f -> minOf(f, 12)
            tempC >= 40f -> minOf(f, 20)
            else -> f
        }
        return f
    }

    private fun dprCap() = when (eco) { 0 -> 0.0; 1 -> 1.5; else -> 1.0 }
    private fun scanMs() = if (sleeping) 5000 else 8000
    private fun cfgJson() = """{"fps":${effectiveFps()},"scanMs":${scanMs()}}"""
    private fun cfgPrefix() =
        "window.__ttvCfg={fps:${effectiveFps()},dpr:${dprCap()},scanMs:${scanMs()},scan:true};\n"

    /** Đẩy cấu hình mới (FPS, chu kỳ quét) xuống mọi frame của trang, không cần tải lại. */
    private fun pushConfig() {
        val j = cfgJson()
        if (j == lastPushed) return
        lastPushed = j
        proxies.forEach { try { it.postMessage(j) } catch (_: Throwable) {} }
    }

    private fun onBridge(message: WebMessageCompat, reply: JavaScriptReplyProxy) {
        val data = message.data ?: return
        if (data.length > 4000) return
        if (data.startsWith("{\"hello\"")) {
            if (proxies.none { it === reply }) {
                proxies.addLast(reply)
                while (proxies.size > 24) proxies.removeFirst()
            }
            try { reply.postMessage(cfgJson()) } catch (_: Throwable) {}
            return
        }
        FarmState.ingest(data)
    }

    /** Gỡ hết script cũ rồi đăng ký lại engine + các script đang BẬT, chạy ở document-start. */
    private fun applyScripts() {
        handlers.forEach { it.remove() }; handlers.clear()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            toast("WebView quá cũ, hãy cập nhật Android System WebView"); return
        }
        handlers += WebViewCompat.addDocumentStartJavaScript(web, cfgPrefix() + engine, setOf("*"))
        store.list().filter { it.enabled }.forEach { s ->
            handlers += WebViewCompat.addDocumentStartJavaScript(web, PRELUDE + s.code, s.originRules())
        }
    }

    // ================= Chế độ ngủ =================

    private fun enterSleep() {
        if (sleeping) return
        sleeping = true; ticks = 0
        sleepView.visibility = View.VISIBLE
        sleepView.refresh(statusLine())
        sleepView.drift()
        fab.visibility = View.GONE
        setBrightness(0.01f)
        WindowCompat.getInsetsController(window, root).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        pushConfig()
        ui.removeCallbacks(tick); ui.postDelayed(tick, 1000)
        toast("Chạm 2 lần để thức dậy")
    }

    private fun exitSleep() {
        if (!sleeping) return
        sleeping = false
        ui.removeCallbacks(tick)
        sleepView.visibility = View.GONE
        fab.visibility = View.VISIBLE
        setBrightness(WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE)
        WindowCompat.getInsetsController(window, root).show(WindowInsetsCompat.Type.systemBars())
        pushConfig()
        scheduleFade()
    }

    private fun setBrightness(v: Float) {
        val lp = window.attributes; lp.screenBrightness = v; window.attributes = lp
    }

    private fun statusLine(): String {
        val fps = effectiveFps()
        val parts = mutableListOf<String>()
        if (battPct >= 0) parts += "🔋 $battPct%"
        if (tempC > 0f) parts += "🌡 ${"%.1f".format(tempC)}°C"
        parts += "⚡ ${ecoNames[eco]} · " + if (fps > 0) "$fps FPS" else "không giới hạn"
        return parts.joinToString("    ")
    }

    // ================= Nút logo nổi =================

    private var fabDragging = false

    private fun placeFab(animate: Boolean) {
        if (root.width == 0 || fab.width == 0) return
        val m = dp(6).toFloat()
        val x = (fabFx * (root.width - fab.width)).coerceIn(m, (root.width - fab.width - m).coerceAtLeast(m))
        val y = (fabFy * (root.height - fab.height)).coerceIn(m, (root.height - fab.height - m).coerceAtLeast(m))
        if (animate) fab.animate().x(x).y(y).setDuration(180).start() else { fab.x = x; fab.y = y }
    }

    private fun scheduleFade() {
        ui.removeCallbacks(fadeFab)
        fab.animate().cancel(); fab.alpha = 0.95f
        ui.postDelayed(fadeFab, 3000)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupFabTouch() {
        var dx = 0f; var dy = 0f; var moved = false; var fired = false
        val longPress = Runnable {
            if (!moved) {
                fired = true
                fab.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                enterSleep()
            }
        }
        fab.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = v.x - e.rawX; dy = v.y - e.rawY; moved = false; fired = false
                    ui.removeCallbacks(fadeFab); v.animate().cancel(); v.alpha = 0.95f
                    ui.postDelayed(longPress, 650)
                }
                MotionEvent.ACTION_MOVE -> {
                    val nx = e.rawX + dx; val ny = e.rawY + dy
                    if (!moved && abs(nx - v.x) + abs(ny - v.y) > dp(8)) {
                        moved = true; fabDragging = true; ui.removeCallbacks(longPress)
                    }
                    if (moved) {
                        v.x = nx.coerceIn(0f, (root.width - v.width).toFloat())
                        v.y = ny.coerceIn(0f, (root.height - v.height).toFloat())
                    }
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longPress)
                    if (moved) {
                        val rangeX = (root.width - v.width).coerceAtLeast(1)
                        val rangeY = (root.height - v.height).coerceAtLeast(1)
                        fabFx = if (v.x + v.width / 2f < root.width / 2f) 0f else 1f   // hít vào mép gần nhất
                        fabFy = (v.y / rangeY).coerceIn(0f, 1f)
                        prefs.edit().putFloat("fab_fx", fabFx).putFloat("fab_fy", fabFy).apply()
                        fabDragging = false
                        placeFab(true)
                    } else if (!fired) showPanel()
                    scheduleFade()
                }
                MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress); fabDragging = false; scheduleFade()
                }
            }
            true
        }
    }

    // ================= Menu =================

    private fun showPanel() {
        var changed = false
        lateinit var dialog: Dialog

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }

        // --- Đầu menu: logo + tên + nút đóng ---
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(roundedImage(R.drawable.logo, 12), LinearLayout.LayoutParams(dp(42), dp(42)))
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(label("TungTomVND", 18f, cText, bold = true))
            addView(label("Giữ logo 1 giây để ngủ nhanh", 12f, cMuted))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "✕"; textSize = 16f; setTextColor(cText); gravity = Gravity.CENTER
            background = ripple(cCard, 22)
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        content.addView(header)

        // --- 4 nút thao tác nhanh ---
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun addTile(emoji: String, text: String, onClick: () -> Unit) {
            tiles.addView(tile(emoji, text, onClick),
                LinearLayout.LayoutParams(0, dp(78), 1f).apply { if (tiles.childCount > 0) leftMargin = dp(8) })
        }
        addTile("😴", "Ngủ") { dialog.dismiss(); enterSleep() }
        addTile("🔄", "Tải lại") { dialog.dismiss(); web.reload() }
        addTile("🧹", "Đặt lại phiên") { FarmState.reset(); toast("Đã đặt lại thời gian & vàng") }
        addTile("➕", "Thêm tiện ích") { dialog.dismiss(); picker.launch(arrayOf("*/*")) }
        content.addView(tiles, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // --- Chế độ chống nóng máy ---
        val ecoCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cCard, 18)
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        ecoCard.addView(label("⚡ Chống nóng máy (treo 24/24)", 14f, cText, bold = true))
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(cSurface, 22)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val desc = label("", 12f, cMuted).apply { setPadding(0, dp(8), 0, 0) }
        val chips = ecoNames.map { TextView(this) }
        fun paint() {
            chips.forEachIndexed { i, c ->
                val on = i == eco
                c.background = if (on) rounded(accent, 20) else ColorDrawable(Color.TRANSPARENT)
                c.setTextColor(if (on) Color.WHITE else cText)
            }
            desc.text = when (eco) {
                0 -> "Chạy hết công suất, máy dễ nóng."
                1 -> "Giới hạn 30 FPS (20 khi ngủ), độ phân giải ≤1.5x."
                else -> "Giới hạn 20 FPS (10 khi ngủ), độ phân giải 1x. Mát nhất."
            } + if (eco > 0) "\nTự giảm thêm khi pin ≥ 40°C." else ""
            if (tempC > 0f) desc.text = desc.text.toString() + "\nPin hiện tại: ${"%.1f".format(tempC)}°C"
        }
        chips.forEachIndexed { i, c ->
            c.apply {
                text = ecoNames[i]; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener {
                    val oldDpr = dprCap()
                    eco = i; prefs.edit().putInt("eco", i).apply()
                    if (dprCap() != oldDpr) changed = true      // đổi độ phân giải cần tải lại trang
                    pushConfig(); paint()
                }
            }
            seg.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        }
        paint()
        ecoCard.addView(seg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        ecoCard.addView(desc)
        content.addView(ecoCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // --- Danh sách tiện ích ---
        val scripts = store.list()
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(label("Tiện ích", 15f, cText, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
        val countTv = label("", 12f, cMuted)
        titleRow.addView(countTv)
        content.addView(titleRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18); bottomMargin = dp(8) })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun updateCount() {
            val rows = list.childCount
            countTv.text = if (scripts.isEmpty() || rows == 0 || list.getChildAt(0).tag == "empty") "" else "$rows script"
        }
        if (scripts.isEmpty()) list.addView(emptyCard().also { it.tag = "empty" })
        scripts.forEach { s ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = ripple(cCard, 16)
                setPadding(dp(16), dp(10), dp(10), dp(10))
                minimumHeight = dp(64)
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(s.name, 15f, cText, bold = true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
            if (s.description.isNotBlank())
                info.addView(label(s.description, 12f, cMuted).apply {
                    maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0)
                })
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val sw = SwitchCompat(this).apply {
                isChecked = s.enabled
                thumbTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(Color.WHITE, if (night) 0xFFB8C0BB.toInt() else 0xFFFFFFFF.toInt()))
                trackTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(accent, if (night) 0xFF4A524D.toInt() else 0xFFC9D1CC.toInt()))
                setOnCheckedChangeListener { _, on -> store.setEnabled(s.id, on); changed = true }
            }
            row.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
            row.setOnClickListener { sw.toggle() }     // chạm cả dòng là bật/tắt

            row.addView(TextView(this).apply {
                text = "🗑"; textSize = 16f; gravity = Gravity.CENTER
                background = ripple(cDangerBg, 22)
                setOnClickListener {
                    confirmDelete(s) {
                        store.delete(s.id); changed = true
                        list.removeView(row)
                        if (list.childCount == 0) list.addView(emptyCard().also { it.tag = "empty" })
                        updateCount()
                    }
                }
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(14) })

            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        updateCount()
        content.addView(list)

        val scroll = MaxHeightScrollView(this, (resources.displayMetrics.heightPixels * 0.88f).toInt()).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
        }
        dialog = sheet(scroll)
        dialog.setOnDismissListener { if (changed) { applyScripts(); web.reload() } }
        dialog.show()
    }

    private fun emptyCard() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        background = rounded(cCard, 16)
        setPadding(dp(20), dp(24), dp(20), dp(24))
        addView(label("Chưa có tiện ích nào", 15f, cText, bold = true).apply { gravity = Gravity.CENTER })
        addView(label("Bấm “➕ Thêm tiện ích” rồi chọn file .js để bắt đầu.", 13f, cMuted).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0)
        })
    }

    private fun confirmDelete(s: UserScript, onConfirm: () -> Unit) {
        lateinit var d: Dialog
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            addView(label("Xóa tiện ích?", 18f, cText, bold = true))
            addView(label("“${s.name}” sẽ bị xóa khỏi app.", 14f, cMuted).apply { setPadding(0, dp(6), 0, dp(18)) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(button("Hủy", cText, cCard, 15f, 16, 14) { d.dismiss() }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(button("Xóa", Color.WHITE, danger, 15f, 16, 14) { d.dismiss(); onConfirm() },
                    LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
            })
        }
        d = sheet(content)
        d.show()
    }

    // ================= Công cụ dựng giao diện =================

    /** Hộp thoại dạng bảng nổi từ dưới lên, bo tròn cả bốn góc, rộng tối đa 540dp. */
    private fun sheet(content: View): Dialog {
        content.background = rounded(cSurface, 28)
        content.clipToOutline = true
        content.outlineProvider = ViewOutlineProvider.BACKGROUND
        return Dialog(this).apply {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
            setContentView(content)
            window?.apply {
                setBackgroundDrawable(InsetDrawable(ColorDrawable(Color.TRANSPARENT), dp(12)))
                setLayout(minOf(resources.displayMetrics.widthPixels, dp(540)), ViewGroup.LayoutParams.WRAP_CONTENT)
                setGravity(Gravity.BOTTOM)
            }
        }
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat(); setColor(color)
    }

    /** Nền bo góc có hiệu ứng gợn sóng khi chạm. */
    private fun ripple(color: Int, radiusDp: Int) = RippleDrawable(
        ColorStateList.valueOf(0x33808080), rounded(color, radiusDp), rounded(Color.WHITE, radiusDp))

    private fun label(text: String, sizeSp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = sizeSp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun tile(emoji: String, text: String, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        background = ripple(cCard, 18)
        setPadding(dp(4), dp(8), dp(4), dp(8))
        addView(TextView(this@MainActivity).apply { this.text = emoji; textSize = 22f; gravity = Gravity.CENTER })
        addView(label(text, 12f, cText, bold = true).apply {
            gravity = Gravity.CENTER; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0)
        })
        setOnClickListener { onClick() }
    }

    private fun button(text: String, fg: Int, bg: Int, sizeSp: Float, padH: Int, padV: Int, onClick: () -> Unit) =
        TextView(this).apply {
            this.text = text; textSize = sizeSp; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = ripple(bg, 24)
            setPadding(dp(padH), dp(padV), dp(padH), dp(padV))
            setOnClickListener { onClick() }
        }

    /** Ảnh bo góc (radius = nửa cạnh thì thành hình tròn). */
    private fun roundedImage(res: Int, radiusDp: Int) = ImageView(this).apply {
        setImageResource(res); scaleType = ImageView.ScaleType.CENTER_CROP
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(radiusDp).toFloat())
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
