package com.example.scriptweb

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

/** Màn hình ngủ: nền đen, logo 1 góc, hiện số liệu phiên treo. Chạm 2 lần để thức dậy. */
class SleepView(ctx: Context, private val onWake: () -> Unit) : FrameLayout(ctx) {
    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private val cLabel = 0xFF5B6E62.toInt()
    private val cValue = 0xFFB5E0C3.toInt()
    private val cBrand = 0xFF7C9486.toInt()

    private val corner = LinearLayout(ctx)
    private val block = LinearLayout(ctx)
    private val vUptime: TextView
    private val vTask: TextView
    private val vPoke: TextView
    private val vLevel: TextView
    private val vGold: TextView
    private val footer: TextView

    init {
        setBackgroundColor(Color.BLACK)
        isClickable = true; isFocusable = true

        // Logo + tên ở 1 góc
        corner.orientation = LinearLayout.HORIZONTAL
        corner.gravity = Gravity.CENTER_VERTICAL
        corner.addView(ImageView(ctx).apply {
            setImageResource(R.drawable.logo); scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.8f; clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat()) }
            }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        corner.addView(TextView(ctx).apply {
            text = "tungtomvnd"; textSize = 14f; setTextColor(cBrand); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), 0, 0, 0)
        })
        addView(corner, LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(18), dp(18), 0, 0) })

        // Khối thông tin ở giữa
        block.orientation = LinearLayout.VERTICAL
        vUptime = row("⏱", "ĐÃ TREO ĐƯỢC")
        vTask = row("🎯", "TREO ĐƯỢC NHỮNG GÌ")
        vPoke = row("🐾", "ĐANG DÙNG POKÉMON")
        vLevel = row("⭐", "ĐANG Ở LEVEL")
        vGold = row("🪙", "VÀNG ĐÃ KIẾM ĐƯỢC")
        footer = TextView(ctx).apply {
            textSize = 11f; setTextColor(cLabel); setPadding(0, dp(14), 0, 0); lineSpacingMultiplier = 1.25f
        }
        block.addView(footer)
        addView(block, LayoutParams(dp(360), -2, Gravity.CENTER))

        val detector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { onWake(); return true }
        })
        setOnTouchListener { _, e -> detector.onTouchEvent(e); true }
    }

    private fun row(icon: String, label: String): TextView {
        val wrap = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
        wrap.addView(TextView(context).apply {
            text = "$icon  $label"; textSize = 11f; setTextColor(cLabel); letterSpacing = 0.06f
        })
        val v = TextView(context).apply {
            textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(cValue)
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(2), 0, 0)
        }
        wrap.addView(v)
        block.addView(wrap, LinearLayout.LayoutParams(-1, -2))
        return v
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val lp = block.layoutParams
        lp.width = minOf(w - dp(48), dp(420)).coerceAtLeast(dp(200))
        block.layoutParams = lp
    }

    fun refresh(status: String) {
        vUptime.text = FarmState.uptimeText()
        vTask.text = FarmState.farmed ?: "—"
        vPoke.text = FarmState.pokemon ?: "—"
        vLevel.text = FarmState.level?.let { "Lv. $it" } ?: "—"
        vGold.text = FarmState.goldText()
        val note = if (FarmState.hasData) "" else "\nChưa nhận được dữ liệu từ script"
        footer.text = status + note + "\nChạm 2 lần để thức dậy"
    }

    /** Dịch nhẹ vị trí chữ/logo theo thời gian để tránh in hằn màn hình OLED. */
    fun drift() {
        val r = dp(16)
        block.animate().translationX(Random.nextInt(-r, r + 1).toFloat())
            .translationY(Random.nextInt(-r, r + 1).toFloat()).setDuration(1200).start()
        val s = dp(8)
        corner.animate().translationX(Random.nextInt(0, s + 1).toFloat())
            .translationY(Random.nextInt(0, s + 1).toFloat()).setDuration(1200).start()
    }
}
