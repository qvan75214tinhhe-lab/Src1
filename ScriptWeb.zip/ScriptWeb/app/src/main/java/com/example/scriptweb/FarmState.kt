package com.example.scriptweb

import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * Số liệu phiên treo. App KHÔNG tự tính gì, chỉ nhận số liệu do script/trang web báo về
 * (TTV_REPORT / TTV_STATE) hoặc do bộ quét chữ của engine đọc được, rồi hiển thị lên màn hình ngủ.
 * Sống theo process nên xoay màn hình / tạo lại Activity không bị mất.
 */
object FarmState {
    private class Fields {
        var pokemon: String? = null
        var level: Int? = null
        var gold: Long? = null
        var farmed: String? = null
    }

    private val api = Fields()    // do script báo (ưu tiên)
    private val scan = Fields()   // do bộ quét chữ đọc được (dự phòng)
    private var lastGold: Long? = null

    var startedAt: Long = SystemClock.elapsedRealtime(); private set
    var earned: Long = 0L; private set

    val pokemon get() = api.pokemon ?: scan.pokemon
    val level get() = api.level ?: scan.level
    val gold get() = api.gold ?: scan.gold
    val farmed get() = api.farmed ?: scan.farmed
    val hasData get() = pokemon != null || level != null || gold != null || farmed != null

    private val nf = NumberFormat.getInstance(Locale("vi", "VN"))
    fun fmt(n: Long): String = nf.format(n)

    fun reset() {
        startedAt = SystemClock.elapsedRealtime()
        earned = 0L
        lastGold = gold
    }

    fun uptimeText(): String {
        val s = (SystemClock.elapsedRealtime() - startedAt) / 1000
        val d = s / 86400; val h = (s % 86400) / 3600; val m = (s % 3600) / 60; val sec = s % 60
        val hms = "%02d:%02d:%02d".format(h, m, sec)
        return if (d > 0) "$d ngày $hms" else hms
    }

    fun goldText(): String {
        val g = gold ?: return "—"
        return "+${fmt(earned)}   ·   hiện có ${fmt(g)}"
    }

    fun ingest(raw: String) {
        val o = try { JSONObject(raw) } catch (_: Exception) { return }
        val f = if (o.optString("src") == "scan") scan else api

        (o.opt("pokemon") as? String)?.trim()?.takeIf { it.isNotEmpty() }?.let { f.pokemon = it.take(40) }
        (o.opt("level") ?: o.opt("lv"))?.let { toNum(it) }?.takeIf { it in 1..9999 }?.let { f.level = it.toInt() }
        o.opt("gold")?.let { toNum(it) }?.takeIf { it > 0 }?.let { f.gold = it }
        farmedText(o.opt("farmed") ?: o.opt("task"))?.let { f.farmed = it }

        // Chỉ cộng phần vàng TĂNG THÊM (tiêu vàng không làm giảm số đã kiếm)
        val g = gold
        if (g != null) {
            val prev = lastGold
            if (prev != null && g > prev) earned += g - prev
            lastGold = g
        }
    }

    private fun toNum(v: Any): Long? = when (v) {
        is Number -> v.toLong()
        is String -> parseNum(v)
        else -> null
    }

    /** Đọc các dạng như 12345, "12,345", "1.234.567", "1.2K", "3M". */
    private fun parseNum(s: String): Long? {
        var t = s.trim().lowercase().replace(" ", "")
        val mult = when {
            t.endsWith("k") -> 1e3
            t.endsWith("m") -> 1e6
            t.endsWith("b") -> 1e9
            else -> 1.0
        }
        if (mult != 1.0) t = t.dropLast(1)
        t = if (mult == 1.0 && Regex("^\\d{1,3}([.,]\\d{3})+$").matches(t)) t.replace(Regex("[.,]"), "")
        else t.replace(',', '.')
        val d = t.toDoubleOrNull() ?: return null
        return (d * mult).toLong()
    }

    private fun farmedText(v: Any?): String? {
        val s = when (v) {
            is String -> v
            is JSONArray -> (0 until v.length()).joinToString(" · ") { v.opt(it).toString() }
            is JSONObject -> v.keys().asSequence().joinToString(" · ") { "$it ${v.opt(it)}" }
            else -> null
        }
        return s?.trim()?.take(200)?.takeIf { it.isNotEmpty() }
    }
}
