// TungTomVND engine: giảm tải đồ họa + cầu nối gửi số liệu về màn hình ngủ.
(function () {
  'use strict';
  if (window.__ttvInit) return;
  window.__ttvInit = true;

  var cfg = window.__ttvCfg || {};
  var fps = cfg.fps || 0;          // 0 = không giới hạn
  var scanMs = cfg.scanMs || 8000;

  function hasBridge() {
    return typeof window.TTV === 'object' && window.TTV && typeof window.TTV.postMessage === 'function';
  }
  function sendRaw(s) { try { if (hasBridge()) window.TTV.postMessage(s); } catch (e) {} }
  function send(o) { try { sendRaw(JSON.stringify(o)); } catch (e) {} }

  // 1) Giới hạn độ phân giải canvas (devicePixelRatio) -> giảm mạnh tải GPU
  if (cfg.dpr > 0) {
    try {
      var real = window.devicePixelRatio || 1;
      var capped = Math.min(real, cfg.dpr);
      Object.defineProperty(window, 'devicePixelRatio', { configurable: true, get: function () { return capped; } });
    } catch (e) {}
  }

  // 2) Giới hạn FPS bằng cách bọc requestAnimationFrame (vẫn giữ timestamp thật)
  var rawRaf = window.requestAnimationFrame.bind(window);
  var rawCancel = window.cancelAnimationFrame.bind(window);
  var seq = 0, pending = {}, last = 0, accepted = -1;
  window.requestAnimationFrame = function (cb) {
    var id = ++seq;
    var tick = function (ts) {
      if (fps > 0 && ts !== accepted) {
        if (ts - last < 1000 / fps - 2) { pending[id] = rawRaf(tick); return; }
        accepted = ts; last = ts;
      }
      delete pending[id];
      cb(ts);
    };
    pending[id] = rawRaf(tick);
    return id;
  };
  window.cancelAnimationFrame = function (id) {
    var r = pending[id];
    if (r !== undefined) { rawCancel(r); delete pending[id]; } else { rawCancel(id); }
  };

  // 3) Nhận cấu hình sống từ app (FPS, chu kỳ quét)
  if (hasBridge()) {
    window.TTV.onmessage = function (ev) {
      try {
        var c = JSON.parse(ev.data);
        if (typeof c.fps === 'number') fps = c.fps;
        if (typeof c.scanMs === 'number') scanMs = c.scanMs;
      } catch (e) {}
    };
    send({ hello: 1 });
  }

  // 4) API cho script: TTV_REPORT({pokemon:'Pikachu', level:25, gold:12345, farmed:'Rare Candy x2'})
  var pend = null, timer = 0, lastSent = '';
  function flush() {
    timer = 0;
    if (!pend) return;
    var s;
    try { s = JSON.stringify(pend); } catch (e) { pend = null; return; }
    pend = null;
    if (s !== lastSent) { lastSent = s; sendRaw(s); }
  }
  window.TTV_REPORT = function (o) {
    if (!o || typeof o !== 'object') return;
    pend = Object.assign(pend || { src: 'api' }, o, { src: 'api' });
    if (!timer) timer = setTimeout(flush, 500);
  };

  // 5) Quét chữ trên trang (dự phòng khi script không tự gọi TTV_REPORT)
  var LV = /^(?:lv\.?|lvl|level|cấp(?: độ)?)\s*[:.]?\s*(\d{1,4})\b/i;
  var LV_LABEL = /^(?:lv\.?|lvl|level|cấp(?: độ)?)\s*[:.]?$/i;
  var GOLD_WORD = '(?:gold|vàng|coins?|money|💰|🪙|₽)';
  var GOLD = new RegExp('^' + GOLD_WORD + '\\s*[:.]?\\s*(\\d[\\d.,]*\\s*[kmb]?)$', 'i');
  var GOLD_LABEL = new RegExp('^' + GOLD_WORD + '\\s*[:.]?$', 'i');
  var NUM = /^\d[\d.,]*\s*[kmb]?$/i;
  var POKE = /^(?:pok[eé]mon|đang dùng|đang chơi|active|current|main)\s*[:：]\s*([^\d:]{2,30})$/i;

  function scan() {
    if (!document.body) return null;
    var nodes = [], n, c = 0;
    var w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while ((n = w.nextNode()) && c < 3000) {
      c++;
      var p = n.parentNode && n.parentNode.nodeName;
      if (p === 'SCRIPT' || p === 'STYLE') continue;
      var t = (n.nodeValue || '').trim();
      if (t && t.length <= 60) nodes.push(t);
    }
    var out = {}, m, any = false;
    for (var i = 0; i < nodes.length; i++) {
      var t2 = nodes[i], nx = nodes[i + 1] || '';
      if (out.level == null) {
        if ((m = LV.exec(t2))) { out.level = +m[1]; any = true; }
        else if (LV_LABEL.test(t2) && /^\d{1,4}$/.test(nx)) { out.level = +nx; any = true; }
      }
      if (out.gold == null) {
        if ((m = GOLD.exec(t2))) { out.gold = m[1]; any = true; }
        else if (GOLD_LABEL.test(t2) && NUM.test(nx)) { out.gold = nx; any = true; }
      }
      if (out.pokemon == null && (m = POKE.exec(t2))) { out.pokemon = m[1].trim(); any = true; }
    }
    return any ? out : null;
  }

  var lastScan = '';
  function cycle() {
    try {
      var st = window.TTV_STATE;                       // script có thể gán sẵn object trạng thái
      if (st && typeof st === 'object') window.TTV_REPORT(st);
      if (cfg.scan !== false) {
        var r = scan();
        if (r) {
          r.src = 'scan';
          var s = JSON.stringify(r);
          if (s !== lastScan) { lastScan = s; sendRaw(s); }
        }
      }
    } catch (e) {}
    setTimeout(cycle, scanMs);
  }
  setTimeout(cycle, 2500);
})();
